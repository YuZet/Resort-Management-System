﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
//Tee Yu Zet, S10221991B

namespace S10221991_PRGM2_Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                MainMenu();
                Console.Write("Enter your option: ");
                int option = Convert.ToInt32(Console.ReadLine());

                if (option == 1)
                {
                    Option1();
                }
                else if (option == 2)
                {
                    Option2();
                }
                else if (option == 3)
                {

                }
                else if (option == 4)
                {

                }
                else if (option == 5)
                {

                }
                else if (option == 6)
                {

                }
                else if (option == 7)
                {

                }
                else if (option == 8)
                {

                }
                else if (option == 9)
                {
                    Console.WriteLine("Thank you ~ Tee Yu Zet, S10221991B");
                    break;
                }
                Console.ReadLine();
            }
        }

        //Show main menu
        static void MainMenu()
        {
            Console.WriteLine("MENU");
            Console.WriteLine("=====");
            Console.WriteLine("1. List all Guests");
            Console.WriteLine("2. List all Resorts");
            Console.WriteLine("3. Register guest");
            Console.WriteLine("4. Rent a resort");
            Console.WriteLine("5. List all rental details for a guest");
            Console.WriteLine("6. List all rental details for bungalows or apartments");
            Console.WriteLine("7. List total nubmer of days resort is rented by guest");
            Console.WriteLine("8. Check out");
            Console.WriteLine("9. Exit");
        }

        //List all guests
        static void Option1()
        {           
            using (StreamReader sr = new StreamReader("Guests.csv"))
            {
                //print header
                string data;
                data = sr.ReadLine();
                string[] header = data.Split(',');
                Console.WriteLine("{0, -5} {1, -15} {2, -15} {3, -15} {4, -15}", "S/O", header[0], header[1], header[2], header[3]);
                //print info
                int i = 1;
                while ((data = sr.ReadLine()) != null)
                {
                    string[] info = data.Split(',');
                    Console.WriteLine("{0, -5} {1, -15} {2, -15} {3, -15} {4, -15}", i, info[0], info[1], info[2], info[3]);
                    i++;
                }
            }
        }

        //List all resorts
        static void Option2()
        {
            using (StreamReader sr = new StreamReader("Resorts.csv"))
            {
                //print header
                string data;
                data = sr.ReadLine();
                string[] header = data.Split(',');
                Console.WriteLine("{0, -5} {1, -15} {2, -15} {3, -15} {4, -15} {5, -15} {6, -15} {7, -15}", "S/O", header[0], header[1], header[2], header[3], header[4], header[5], header[6]);
                //print info
                int i = 1;
                while ((data = sr.ReadLine()) != null)
                {
                    string[] info = data.Split(',');
                    Console.WriteLine("{0, -5} {1, -15} {2, -15} {3, -15} {4, -15} {5, -15} {6, -15} {7, -15}",i, info[0], info[1], info[2], info[3], info[4], info[5], info[6]);
                    i++;
                }
            }
        }

        //Register guest
        static void Option3()
        {
        }
    }
}
