﻿using System;
using System.Collections.Generic;
using System.Text;
//Tee Yu Zet, S10221991B
namespace S10221991_PRGM2_Assignment
{
    class Bungalow : Resort
    {
        public bool Pool { get; set; }

        public Bungalow() { }
        public Bungalow(int rId, string blk, double rate, bool pool)
        {
            Pool = pool;
        }

        public override double ComputeResortCost(int rId)
        {
            return 1.0;//not completed
        }

        public override string ToString()
        {
            return "Pool: " + Pool;
        }
    }
}
