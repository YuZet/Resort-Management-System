﻿using System;
using System.Collections.Generic;
using System.Text;
//Tee Yu Zet, S10221991B
namespace S10221991_PRGM2_Assignment
{
    class Rental
    {
        public int RentalNo { get; set; }
        public Person Guest { get; set; }
        public DateTime ArrivalDate { get; set; }
        public DateTime DepartureDate { get; set; }
        public Resort Resort { get; set; }
        public bool PaymentStatus { get; set; }

        public Rental() { }
        public Rental(int rNo, Person guest, DateTime aDate, DateTime dDate, Resort resort, bool payStatus)
        {
            RentalNo = rNo;
            Guest = guest;
            ArrivalDate = aDate;
            DepartureDate = dDate;
            Resort = resort;
            PaymentStatus = payStatus;
        }

        public double ComputeRentalCost()
        {
            return 1.0;//not completed

        }

        public override string ToString()
        {
            return "RentalNo: " + RentalNo + "Guest: " + Guest + "ArrivalDate: " + ArrivalDate + "DepartureDate" + DepartureDate + "Resort: " + Resort + "PaymentStatus: " + PaymentStatus;
        }
    }
}
