﻿using System;
using System.Collections.Generic;
using System.Text;
//Tee Yu Zet, S10221991B
namespace S10221991_PRGM2_Assignment
{
    class Person
    {
        public string Nric { get; set; }
        public string Name { get; set; }
        public string Tel { get; set; }
        public bool Member { get; set; }
        public List<Rental> RentalList { get; set; }

        public Person() { RentalList = new List<Rental>(); }
        public Person(string nric, string name, string tel, bool mem)
        {
            Nric = nric;
            Name = name;
            Tel = tel;
            Member = mem;
            RentalList = new List<Rental>();
        }

        public void AddRental(Rental rent)
        {
            RentalList.Add(rent);
        }

        public override string ToString()
        {
            return "Nric: " + Nric + "Name: " + Name + "Tel: " + Tel + "Member: " + Member; //rentalList not added in ToString()
        }
    }
}
