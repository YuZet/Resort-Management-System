﻿using System;
using System.Collections.Generic;
using System.Text;
//Tee Yu Zet, S10221991B
namespace S10221991_PRGM2_Assignment
{
    abstract class Resort
    {
        public int ResortId { get; set; }
        public string Block { get; set; }
        public double Rate { get; set; }

        public Resort() { }
        public Resort(int rId, string blk, double rate)
        {
            ResortId = rId;
            Block = blk;
            Rate = rate;
        }

        public virtual double ComputeResortCost(int rId)
        {
            return 1.0; //not completed
        }

        public override string ToString()
        {
            return "ResortId: " + ResortId + "Block: " + Block + "Rate: " + Rate;
        }
    }
}
