﻿using System;
using System.Collections.Generic;
using System.Text;
//Tee Yu Zet, S10221991B
namespace S10221991_PRGM2_Assignment
{
    class Apartment : Resort
    {
        public int Level { get; set; }
        public int UnitNo { get; set; }
        public bool SeaView { get; set; }

        public Apartment(int rId, string blk, double rate, int lvl, int uNo, bool sView)
        {
            Level = lvl;
            UnitNo = uNo;
            SeaView = sView;
        }

        public override double ComputeResortCost(int rId)
        {
            return 1.0;//not completed
        }

        public override string ToString()
        {
            return "Level: " + Level + "UnitNo: " + UnitNo + "SeaView: " + SeaView;
        }
    }
}
